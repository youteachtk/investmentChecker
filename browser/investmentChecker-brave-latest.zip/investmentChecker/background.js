'use strict';
const WORKFLOW_URL = 'https://api.github.com/repos/youteachtk/investmentChecker/actions/workflows/ingest_quotes.yml/dispatches';
const ACTINVER = /^https:\/\/(?:www\.)?retoactinver\.com(?:[\/:#?]|$)/i;
const stamp = () => new Date().toLocaleString('es-MX');
const MAX_RUN_AGE_MS = 7 * 60 * 1000;

// A toolbar click opens a normal, resizable window. Unlike an action popup,
// it stays open while the user switches to Actinver to enter an order manually.
let panelOpening=null;
async function openInvestmentCheckerPanel(){
  if(panelOpening)return panelOpening;
  panelOpening=(async()=>{
    const {investmentCheckerPanelId}=await chrome.storage.local.get('investmentCheckerPanelId');
    if(Number.isInteger(investmentCheckerPanelId)){
      try{
        const existing=await chrome.windows.get(investmentCheckerPanelId);
        if(existing?.id){
          await chrome.windows.update(existing.id,{focused:true});
          return existing.id;
        }
      }catch(_){}
    }
    const panel=await chrome.windows.create({
      url:chrome.runtime.getURL('popup.html'),type:'popup',
      width:440,height:720,focused:true
    });
    if(Number.isInteger(panel?.id)){
      await chrome.storage.local.set({investmentCheckerPanelId:panel.id});
      return panel.id;
    }
    throw Error('Brave no pudo crear la ventana de InvestmentChecker.');
  })();
  try{return await panelOpening;}finally{panelOpening=null;}
}
chrome.action?.onClicked?.addListener(()=>{void openInvestmentCheckerPanel();});
chrome.windows?.onRemoved?.addListener(async id=>{
  const {investmentCheckerPanelId}=await chrome.storage.local.get('investmentCheckerPanelId');
  if(id===investmentCheckerPanelId)await chrome.storage.local.remove('investmentCheckerPanelId');
});

async function setStatus(message, running) {
  await chrome.storage.local.set({syncStatus:message, syncRunning:running});
}

// Access only tab URL metadata; never store or upload other tabs' URLs.
async function getActinverTabs(){
  const all=await chrome.tabs.query({});
  return {allCount:all.length,matches:all.filter(t=>t?.id && ACTINVER.test(t.url||t.pendingUrl||''))};
}
async function getTabDiagnostics(){
  const {allCount,matches}=await getActinverTabs();
  let sitePermission='no se pudo determinar';
  try {
    const granted=await chrome.permissions.contains({
      origins:['https://retoactinver.com/*','https://www.retoactinver.com/*']
    });
    sitePermission=granted?'concedido':'no concedido';
  }catch(_){}
  let diagnostic='Brave detecta '+allCount+' pestaña(s). Actinver: '+matches.length+'. Permiso del sitio: '+sitePermission+'.';
  if(!matches.length) diagnostic+=' Si Actinver sigue abierto en esta misma instalación de Brave, revisa el Acceso al sitio en Detalles de esta extensión.';
  return {allCount,matchCount:matches.length,sitePermission,diagnostic};
}

const MONITOR_URL = 'https://www.retoactinver.com/RetoActinver/#/capitales';
const isMonitorTab = t => /\/#\/capitales(?:[/?#]|$)/i.test(t?.url || '');
async function waitForPage(tabId, maxMs=25000) {
  const until=Date.now()+maxMs;
  while(Date.now()<until) {
    try {
      const tab=await chrome.tabs.get(tabId);
      if(tab.status==='complete') {await new Promise(r=>setTimeout(r,1100));return true;}
    }catch{return false;}
    await new Promise(r=>setTimeout(r,350));
  }
  return false;
}
// Public quotes are always collected in a separate INACTIVE tab. Never
// click categories or paginator controls inside the user's visible tab.
function marketUrlForSession(tab) {
  const source=tab?.url||tab?.pendingUrl||'';
  const host=/^https:\/\/www\.retoactinver\.com(?:[\/:#?]|$)/i.test(source)?
    'https://www.retoactinver.com':'https://retoactinver.com';
  return host+'/RetoActinver/#/capitales';
}
async function createIsolatedMarketTab(sourceTab,runId) {
  if(!Number.isInteger(sourceTab?.id)||
     !ACTINVER.test(sourceTab.url||sourceTab.pendingUrl||''))
    throw Error('No se encontró una sesión Actinver para la pestaña de lectura.');
  const tab=await chrome.tabs.create({
    url:marketUrlForSession(sourceTab),
    openerTabId:sourceTab.id,
    active:false
  });
  await chrome.storage.local.set({
    syncTemporaryTabId:tab.id,syncTempRunId:runId
  });
  if(!(await waitForPage(tab.id))){
    await cleanupTemporarySyncTab(tab.id,runId);
    throw Error('No se pudo cargar Capitales en la pestaña secundaria.');
  }
  return tab;
}

async function cleanupTemporarySyncTab(expectedId=null,ownerId=null) {
  const s=await chrome.storage.local.get(['syncTemporaryTabId','syncRunId','syncTempRunId']);
  if(!s.syncTemporaryTabId)return;
  if(ownerId!==null && (s.syncTempRunId!==ownerId || s.syncRunId!==ownerId))return;
  if(expectedId!==null && expectedId!==s.syncTemporaryTabId)return;
  const tabId=s.syncTemporaryTabId;
  await chrome.storage.local.remove('syncTemporaryTabId');
  try{await chrome.tabs.remove(tabId);}catch(_){}
}
// Chrome can discard a background tab between opening and script injection.
// Retry once with a new, independently owned temporary tab rather than failing
// with the raw error "No tab with id: ...".
async function injectQuotesWithRetry(firstTabId, runId) {
  let tabId=firstTabId;
  for(let attempt=0;attempt<2;attempt++){
    // Never inject into a tab we did not create and own for this exact run.
    const state=await chrome.storage.local.get([
      'syncTemporaryTabId','syncTempRunId','syncRunId'
    ]);
    if(state.syncTemporaryTabId!==tabId ||
       state.syncTempRunId!==runId || state.syncRunId!==runId){
      await setStatus('Cotizaciones detenidas: la pestaña secundaria no coincide.',false);
      return;
    }
    try{
      await chrome.tabs.get(tabId);
      await chrome.storage.local.set({syncTabId:tabId});
      await chrome.scripting.executeScript({
        target:{tabId},files:['collector.js'],world:'ISOLATED'
      });
      // Wait for collector.js to finish before removing its frame.
      await cleanupTemporarySyncTab(tabId,runId);
      return;
    }catch(err){
      // Brave can report a destroyed frame after GitHub has already accepted
      // all 226 rows. Preserve that confirmed result; never overwrite it
      // with a misleading error or upload a duplicate capture.
      const done=await chrome.storage.local.get(['lastSync','syncStartedAt','syncRunId']);
      if(done.syncRunId===runId && Number.isFinite(done.lastSync) &&
         done.lastSync>=done.syncStartedAt){
        await cleanupTemporarySyncTab(tabId,runId);
        return;
      }
      const missing=/No tab with id|tab was closed|No frame with id|Frame with ID [0-9]+ was removed/i.test(String(err?.message||''));
      if(!missing||attempt===1){
        await setStatus('Error de lectura de Actinver: '+(missing?'pestaña cerrada durante la captura':err.message),false);
        await cleanupTemporarySyncTab(null,runId);
        return;
      }
      const old=tabId;
      // Only clean up the failed temporary tab, not another run's tab.
      await cleanupTemporarySyncTab(old,runId);
      // A lost disposable tab can only be replaced by another disposable
      // tab. Never fall back to the user's existing Capitales page.
      const found=await getActinverTabs();
      const original=found.matches.find(t=>t.active&&t.id!==old)
        ||found.matches.find(t=>t.id!==old);
      if(!original){
        await setStatus('Error: no quedó una sesión de Actinver abierta.',false);
        return;
      }
      try {
        tabId=(await createIsolatedMarketTab(original,runId)).id;
      } catch(error) {
        await setStatus('Error: '+error.message,false);
        return;
      }
    }
  }
}

async function startSync(tabId = null) {
  const s=await chrome.storage.local.get(['githubToken','syncRunning','syncStartedAt']);
  if(!s.githubToken)return {ok:false,error:'Aún no hay token de cotizaciones públicas.'};
  if(s.syncRunning && s.syncStartedAt && Date.now()-s.syncStartedAt<MAX_RUN_AGE_MS)
    return {ok:false,error:'Ya hay una sincronización en curso.'};
  const found=await getActinverTabs();
  if(!found.matches.length)return {ok:false,error:'Abre Actinver con sesión iniciada; se sincronizará automáticamente.'};
  // A slow or unavailable private GitHub connection must never block
  // the verified 226-row public collector. Private recovery runs in its own flow.
  const runId='sync-'+Date.now()+'-'+Math.floor(Math.random()*100000);
  await chrome.storage.local.set({syncRunId:runId,syncStartedAt:Date.now(),syncRunning:true,
    syncStatus:'Recopilando cotizaciones y cartera en pestañas secundarias…'});
  try {
    const sourceTab=(tabId!==null?found.matches.find(t=>t.id===tabId):null)
      ||found.matches.find(t=>t.active)
      ||found.matches[0];
    // Always isolate the 226-row collector. Even when Capitales is already
    // visible, that original user tab stays completely untouched.
    const tab=await createIsolatedMarketTab(sourceTab,runId);
    // Public quotes have their own disposable Capitales tab. Do not wait for
    // portfolio navigation or private GitHub, which can stall indefinitely.
    // The private reader starts from the original user's Actinver tab (read
    // only), opening its own disposable portfolio tab if needed.
    void runPortfolioSync(sourceTab.id)
      .then(result=>chrome.storage.local.set({privateSyncStatus:result?.message||'Lectura privada completada.'}))
      .catch(error=>chrome.storage.local.set({privateSyncStatus:'Cartera: '+error.message}));
    void injectQuotesWithRetry(tab.id,runId).catch(async error=>{
      await setStatus('Error inesperado en cotizaciones: '+error.message,false);
      await cleanupTemporarySyncTab(null,runId);
    });
    return {ok:true};
  }catch(error){
    await setStatus('Error al iniciar lectura: '+error.message,false);
    await cleanupTemporarySyncTab(null,runId);
    return {ok:false,error:error.message};
  }
}
async function upload(payload) {
  if (!payload || !Array.isArray(payload.rows) || payload.rows.length!==226)
    throw Error('El catálogo está incompleto, no se enviarán datos.');
  const body = JSON.stringify(payload);
  if (body.length > 62000) throw Error('Captura demasiado larga para GitHub Actions.');
  const {githubToken}=await chrome.storage.local.get('githubToken');
  if (!githubToken) throw Error('Falta token de GitHub.');
  const response=await fetch(WORKFLOW_URL,{
    method:'POST',
    headers:{Authorization:'Bearer '+githubToken,Accept:'application/vnd.github+json',
      'X-GitHub-Api-Version':'2022-11-28','Content-Type':'application/json'},
    body:JSON.stringify({ref:'main',inputs:{payload:body}})
  });
  if (response.status!==204) {
    const detail=(await response.text()).slice(0,250);
    throw Error('GitHub respondió '+response.status+' '+detail);
  }
}
async function route(msg,sender) {
  // These read-only additions are independent of the proven public
  // collection path. Do not modify startSync/injectQuotesWithRetry.
  if(msg?.type==='CHECK_EXTENSION_UPDATE'){
    try{
      await readPublishedControl();
      const status=await chrome.storage.local.get([
        'lastPublishedExtensionVersion','lastNativeUpdateStatus',
        'lastNativeUpdateError','lastNativeUpdateSucceeded']);
      return {ok:true,loaded:chrome.runtime.getManifest().version,
        published:status.lastPublishedExtensionVersion||null,
        updater:status.lastNativeUpdateStatus||'NO_ATTEMPT',
        error:status.lastNativeUpdateError||null};
    }catch(error){
      return {ok:false,error:'No se pudo consultar GitHub: '+
        String(error?.message||error).slice(0,140)};
    }
  }
  if(msg?.type==='CHECK_QUOTES'){
    const response=await fetch(
      'https://raw.githubusercontent.com/youteachtk/investmentChecker/main/output/actinver_quotes.json?check='+Date.now(),
      {cache:'no-store'});
    if(!response.ok)return {ok:false,error:'GitHub no respondió.'};
    const doc=await response.json();
    if(doc?.total!==226||!Array.isArray(doc?.quotes)||
       doc.quotes.length!==226||typeof doc.validated_at!=='string')
      return {ok:false,error:'GitHub aún no validó las 226 cotizaciones.'};
    return {ok:true,total:226,captured_at:doc.captured_at,validated_at:doc.validated_at};
  }
  if(msg?.type==='ORDER_PREVIEW')return await orderPreview();
  if(msg?.type==='ORDER_SIMULATION')return await orderPreview({simulation_only:true});
  if(msg?.type==='ORDER_APPROVE')return await orderApprove(msg);
  if(msg?.type==='ORDER_INSPECT_UI')return {ok:false,status:'CONTEST_SAFE_COPY_ONLY',
    error:'La inspección automatizada de formularios está deshabilitada; copia los datos manualmente.'};
  if(msg?.type==='ORDER_HISTORY')return await orderHistoryStatus();
  if(msg?.type==='ORDER_STAGE_VISA')return {ok:false,status:'CONTEST_SAFE_COPY_ONLY',
    error:'El autollenado está deshabilitado para el Reto Actinver.'};
  if (msg?.type==='PRIVATE_CONFIG') return await configurePrivatePortfolio(msg);
  if (msg?.type==='PRIVATE_START') return await capturePrivatePortfolio();
  if (msg?.type==='PRIVATE_CAPTURE') return await acceptPrivateCapture(msg,sender);
  if (msg?.type==='START_SYNC') return await startSync();
  if (msg?.type==='DIAGNOSE') return {ok:true,...await getTabDiagnostics()};
  if (msg?.type==='TOGGLE_AUTO') {
    const {autoSync}=await chrome.storage.local.get('autoSync');
    const enabled=!autoSync;
    await chrome.storage.local.set({autoSync:enabled});
    if (enabled) await chrome.alarms.create('quote_sync',{periodInMinutes:30});
    else await chrome.alarms.clear('quote_sync');
    return {ok:true,enabled};
  }
  if (['PROGRESS','COLLECT_FAILED','COLLECT_DONE'].includes(msg?.type)) {
    const {syncTabId,syncRunning,syncRunId}=await chrome.storage.local.get(['syncTabId','syncRunning','syncRunId']);
    if (sender.tab?.id!==syncTabId || !syncRunning) return {ok:false,error:'Captura no reconocida'};
    if (msg.type==='PROGRESS') {
      await setStatus(msg.status,true);
      return {ok:true};
    }
    if (msg.type==='COLLECT_FAILED') {
      await setStatus('Cotizaciones pendientes: '+(msg.reason||'lectura incompleta')+
        '. Guardando diagnóstico privado; la cartera se procesa por separado.',false);
      let diagnosticStatus='unavailable';
      try {
        const saved=await uploadPrivateDiagnostic(msg.diagnostic);
        diagnosticStatus=saved.ok?'saved':saved.reason;
      }catch(error){
        diagnosticStatus='upload_failed';
      }
      await chrome.storage.local.set({lastDiagnosticStatus:diagnosticStatus});
      // Background injector closes its own tab after collector.js completes.
      return {ok:true};
    }
    try {
      await setStatus('226 cotizaciones capturadas. Validando en GitHub…',true);
      await upload(msg.payload);
      await chrome.storage.local.set({lastSync:Date.now()});
      await setStatus('226 cotizaciones enviadas a GitHub · '+stamp()+
        '. Consulta también el estado de la cartera privada.',false);
      // Background injector closes its own tab after collector.js completes.
      return {ok:true};
    }catch(err) {
      await setStatus('Error en envío público: '+err.message+
        '. La cartera privada no se interrumpe.',false);
      // Background injector closes its own tab after collector.js completes.
      return {ok:false,error:err.message};
    }
  }
  return {ok:false,error:'Comando no reconocido'};
}
chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
  route(msg,sender).then(result=>reply({...result,version:chrome.runtime.getManifest().version})).catch(async err=>{
    await setStatus('Error: '+err.message,false);
    reply({ok:false,error:err.message});
  });
  return true;
});
chrome.alarms.onAlarm.addListener(async alarm=>{
  if(alarm.name!=='quote_sync') return;
  const s=await chrome.storage.local.get(['autoSync','lastSync']);
  if(!s.autoSync || Date.now()-(s.lastSync||0)<28*60000) return;
  const tabs=await getActinverTabs();
  const tab=tabs.matches.find(t=>t.active);
  if(tab) await startSync(tab.id);
});
async function maybeAutoStart(){
  const s=await chrome.storage.local.get(['autoSync','lastSync','syncRunning','lastAutoAttempt']);
  if(!s.autoSync || s.syncRunning || Date.now()-(s.lastSync||0)<28*60000 ||
     Date.now()-(s.lastAutoAttempt||0)<3*60000)return;
  const tabs=await getActinverTabs();
  if(!tabs.matches.length)return;
  await chrome.storage.local.set({lastAutoAttempt:Date.now()});
  const result=await startSync();
  if(!result.ok)await setStatus('Esperando a Actinver: '+result.error,false);
}
async function ensureAutoSync(){
  const {autoSync}=await chrome.storage.local.get('autoSync');
  if(autoSync===false){await chrome.alarms.clear('quote_sync');return;}
  if(autoSync!==true)await chrome.storage.local.set({autoSync:true});
  await chrome.alarms.create('quote_sync',{periodInMinutes:30});
  await maybeAutoStart();
}
chrome.runtime.onInstalled.addListener(()=>{void ensureAutoSync();});
chrome.runtime.onStartup.addListener(()=>{void ensureAutoSync();});
chrome.tabs.onUpdated.addListener((tabId,info,tab)=>{
  if(info.status==='complete' && ACTINVER.test(tab.url||''))void maybeAutoStart();
});

// Remote read-only quote capture requests initiated from ChatGPT via GitHub.
importScripts('remote.js');
importScripts('private-sync.js');
importScripts('order-preflight.js');
