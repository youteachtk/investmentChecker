'use strict';
const WORKFLOW_URL = 'https://api.github.com/repos/youteachtk/investmentChecker/actions/workflows/ingest_quotes.yml/dispatches';
const ACTINVER = /^https:\/\/(?:www\.)?retoactinver\.com(?:[\/:#?]|$)/i;
const stamp = () => new Date().toLocaleString('es-MX');
const MAX_RUN_AGE_MS = 7 * 60 * 1000;

async function setStatus(message, running) {
  await chrome.storage.local.set({syncStatus:message, syncRunning:running});
}

// Access only tab URL metadata; never store or upload other tabs' URLs.
async function getActinverTabs(){
  const all=await chrome.tabs.query({});
  return {allCount:all.length,matches:all.filter(t=>t?.id && ACTINVER.test(t.url||t.pendingUrl||''))};
}
async function getTabDiagnostics(){
  const {allCount,matches}=await getActinverTabs();
  let sitePermission='no se pudo determinar';
  try {
    const granted=await chrome.permissions.contains({
      origins:['https://retoactinver.com/*','https://www.retoactinver.com/*']
    });
    sitePermission=granted?'concedido':'no concedido';
  }catch(_){}
  let diagnostic='Brave detecta '+allCount+' pestaña(s). Actinver: '+matches.length+'. Permiso del sitio: '+sitePermission+'.';
  if(!matches.length) diagnostic+=' Si Actinver sigue abierto en esta misma instalación de Brave, revisa el Acceso al sitio en Detalles de esta extensión.';
  return {allCount,matchCount:matches.length,sitePermission,diagnostic};
}

const MONITOR_URL = 'https://www.retoactinver.com/RetoActinver/#/capitales';
const isMonitorTab = t => /\/#\/capitales(?:[/?#]|$)/i.test(t?.url || '');
async function waitForPage(tabId, maxMs=25000) {
  const until=Date.now()+maxMs;
  while(Date.now()<until) {
    try {
      const tab=await chrome.tabs.get(tabId);
      if(tab.status==='complete') {await new Promise(r=>setTimeout(r,1100));return true;}
    }catch{return false;}
    await new Promise(r=>setTimeout(r,350));
  }
  return false;
}
// Public quotes are always collected in a separate INACTIVE tab. Never
// click categories or paginator controls inside the user's visible tab.
function marketUrlForSession(tab) {
  const source=tab?.url||tab?.pendingUrl||'';
  const host=/^https:\/\/www\.retoactinver\.com(?:[\/:#?]|$)/i.test(source)?
    'https://www.retoactinver.com':'https://retoactinver.com';
  return host+'/RetoActinver/#/capitales';
}
async function createIsolatedMarketTab(sourceTab,runId,{waitForReady=true}={}) {
  if(!Number.isInteger(sourceTab?.id)||
     !ACTINVER.test(sourceTab.url||sourceTab.pendingUrl||''))
    throw Error('No se encontró una sesión Actinver para la pestaña de lectura.');
  const tab=await chrome.tabs.create({
    url:marketUrlForSession(sourceTab),
    openerTabId:sourceTab.id,
    active:false
  });
  await chrome.storage.local.set({
    syncTemporaryTabId:tab.id,syncTempRunId:runId
  });
  if(waitForReady && !(await waitForPage(tab.id))){
    await cleanupTemporarySyncTab(tab.id,runId);
    throw Error('No se pudo cargar Capitales en la pestaña secundaria.');
  }
  return tab;
}

async function cleanupTemporarySyncTab(expectedId=null,ownerId=null) {
  const s=await chrome.storage.local.get(['syncTemporaryTabId','syncRunId','syncTempRunId']);
  if(!s.syncTemporaryTabId)return;
  if(ownerId!==null && (s.syncTempRunId!==ownerId || s.syncRunId!==ownerId))return;
  if(expectedId!==null && expectedId!==s.syncTemporaryTabId)return;
  const tabId=s.syncTemporaryTabId;
  await chrome.storage.local.remove('syncTemporaryTabId');
  try{await chrome.tabs.remove(tabId);}catch(_){}
}
// Chrome can discard a background tab between opening and script injection.
// Retry once with a new, independently owned temporary tab rather than failing
// with the raw error "No tab with id: ...".
async function injectQuotesWithRetry(firstTabId, runId) {
  let tabId=firstTabId;
  for(let attempt=0;attempt<2;attempt++){
    // Never inject into a tab we did not create and own for this exact run.
    const state=await chrome.storage.local.get([
      'syncTemporaryTabId','syncTempRunId','syncRunId'
    ]);
    if(state.syncTemporaryTabId!==tabId ||
       state.syncTempRunId!==runId || state.syncRunId!==runId){
      await setStatus('Cotizaciones detenidas: la pestaña secundaria no coincide.',false);
      return;
    }
    try{
      await chrome.tabs.get(tabId);
      await chrome.storage.local.set({syncTabId:tabId});
      await chrome.scripting.executeScript({
        target:{tabId},files:['collector.js'],world:'ISOLATED'
      });
      // Wait for collector.js to finish before removing its frame.
      await cleanupTemporarySyncTab(tabId,runId);
      return;
    }catch(err){
      // Brave can report a destroyed frame after GitHub has already accepted
      // all 226 rows. Preserve that confirmed result; never overwrite it
      // with a misleading error or upload a duplicate capture.
      const done=await chrome.storage.local.get(['lastSync','syncStartedAt','syncRunId']);
      if(done.syncRunId===runId && Number.isFinite(done.lastSync) &&
         done.lastSync>=done.syncStartedAt){
        await cleanupTemporarySyncTab(tabId,runId);
        return;
      }
      const missing=/No tab with id|tab was closed|No frame with id|Frame with ID [0-9]+ was removed/i.test(String(err?.message||''));
      if(!missing||attempt===1){
        await setStatus('Error de lectura de Actinver: '+(missing?'pestaña cerrada durante la captura':err.message),false);
        await cleanupTemporarySyncTab(null,runId);
        return;
      }
      const old=tabId;
      // Only clean up the failed temporary tab, not another run's tab.
      await cleanupTemporarySyncTab(old,runId);
      // A lost disposable tab can only be replaced by another disposable
      // tab. Never fall back to the user's existing Capitales page.
      const found=await getActinverTabs();
      const original=found.matches.find(t=>t.active&&t.id!==old)
        ||found.matches.find(t=>t.id!==old);
      if(!original){
        await setStatus('Error: no quedó una sesión de Actinver abierta.',false);
        return;
      }
      try {
        tabId=(await createIsolatedMarketTab(original,runId)).id;
      } catch(error) {
        await setStatus('Error: '+error.message,false);
        return;
      }
    }
  }
}

async function startSync(tabId = null) {
  const s=await chrome.storage.local.get(['githubToken','syncRunning','syncStartedAt']);
  if(!s.githubToken)return {ok:false,error:'Aún no hay token de cotizaciones públicas.'};
  if(s.syncRunning && s.syncStartedAt && Date.now()-s.syncStartedAt<MAX_RUN_AGE_MS)
    return {ok:false,error:'Ya hay una sincronización en curso.'};
  const found=await getActinverTabs();
  if(!found.matches.length)return {ok:false,error:'Abre Actinver con sesión iniciada; se sincronizará automáticamente.'};
  // If a private-only token was put in the public box, recover it before
  // attempting both independent channels.
  await recoverMisplacedPrivateToken();
  const runId='sync-'+Date.now()+'-'+Math.floor(Math.random()*100000);
  await chrome.storage.local.set({syncRunId:runId,syncStartedAt:Date.now(),syncRunning:true,
    syncStatus:'Iniciando sincronización privada y pública en segundo plano…',
    syncProgress:{stage:'Preparando la cartera privada',captured:0,total:226,
      category:null,page:null,updatedAt:Date.now()}});
  try {
    const sourceTab=(tabId!==null?found.matches.find(t=>t.id===tabId):null)
      ||found.matches.find(t=>t.active)
      ||found.matches[0];
    // Always isolate the 226-row collector. Even when Capitales is already
    // visible, that original user tab stays completely untouched.
    // Opening a tab is fast, but loading the Angular app can take 25 seconds.
    // Acknowledge the popup immediately after creating the isolated tab.
    // Continue navigation/read/upload asynchronously with explicit status.
    await chrome.storage.local.set({
      syncProgress:{stage:'Abriendo pestaña secundaria de Capitales',
        captured:0,total:226,category:null,page:null,updatedAt:Date.now()},
      syncStatus:'Abriendo Capitales en segundo plano…'
    });
    const tab=await createIsolatedMarketTab(sourceTab,runId,{waitForReady:false});
    void (async()=>{
      await chrome.storage.local.set({
        syncProgress:{stage:'Esperando carga de Capitales',
          captured:0,total:226,category:null,page:null,updatedAt:Date.now()},
        syncStatus:'Esperando carga de Capitales en segundo plano…'
      });
      if(!(await waitForPage(tab.id)))
        throw Error('Capitales no terminó de cargar en la pestaña secundaria.');
      await chrome.storage.local.set({
        syncProgress:{stage:'Leyendo cartera privada',
          captured:0,total:226,category:null,page:null,updatedAt:Date.now()},
        syncStatus:'Leyendo cartera y posiciones privadas…'
      });
      try{
        const result=await runPortfolioSync(tab.id);
        await chrome.storage.local.set({
          privateSyncStatus:result?.message||'Lectura privada completada.'
        });
      }catch(error){
        await chrome.storage.local.set({
          privateSyncStatus:'Cartera: '+String(error?.message||error)
        });
      }
      await chrome.storage.local.set({
        syncProgress:{stage:'Preparando las 226 cotizaciones',
          captured:0,total:226,category:null,page:null,updatedAt:Date.now()},
        syncStatus:'Preparando lectura de las 226 cotizaciones…'
      });
      await injectQuotesWithRetry(tab.id,runId);
    })().catch(async error=>{
      await setStatus('Error al iniciar la lectura: '+String(error?.message||error),false);
      await chrome.storage.local.set({
        syncProgress:{stage:'Fallo al abrir Capitales',captured:0,
          total:226,category:null,page:null,updatedAt:Date.now()}
      });
      await cleanupTemporarySyncTab(null,runId);
    });
    return {ok:true,stage:'INICIADA',temporaryTabId:tab.id};
  }catch(error){
    await setStatus('Error al iniciar lectura: '+error.message,false);
    await cleanupTemporarySyncTab(null,runId);
    return {ok:false,error:error.message};
  }
}
async function upload(payload) {
  if (!payload || !Array.isArray(payload.rows) || payload.rows.length!==226)
    throw Error('El catálogo está incompleto, no se enviarán datos.');
  const body = JSON.stringify(payload);
  if (body.length > 62000) throw Error('Captura demasiado larga para GitHub Actions.');
  const {githubToken}=await chrome.storage.local.get('githubToken');
  if (!githubToken) throw Error('Falta token de GitHub.');
  const response=await fetch(WORKFLOW_URL,{
    method:'POST',
    headers:{Authorization:'Bearer '+githubToken,Accept:'application/vnd.github+json',
      'X-GitHub-Api-Version':'2022-11-28','Content-Type':'application/json'},
    body:JSON.stringify({ref:'main',inputs:{payload:body}})
  });
  if (response.status!==204) {
    const detail=(await response.text()).slice(0,250);
    throw Error('GitHub respondió '+response.status+' '+detail);
  }
}
async function route(msg,sender) {
  if (msg?.type==='CHECK_QUOTES') {
    // Public snapshot only, never expose the private portfolio or token.
    const url='https://raw.githubusercontent.com/youteachtk/investmentChecker/main/output/actinver_quotes.json?check='+Date.now();
    const response=await fetch(url,{cache:'no-store'});
    if(!response.ok)return {ok:false,error:'GitHub no respondió a la comprobación pública.'};
    const snapshot=await response.json();
    const valid=snapshot?.total===226 &&
      Array.isArray(snapshot?.quotes)&&snapshot.quotes.length===226 &&
      typeof snapshot?.validated_at==='string';
    if(!valid)return {ok:false,error:'GitHub no confirma una captura válida de 226 instrumentos.'};
    return {ok:true,total:226,captured_at:snapshot.captured_at,
      validated_at:snapshot.validated_at};
  }
  if (msg?.type==='ORDER_PREVIEW') return await orderPreview();
  if (msg?.type==='ORDER_APPROVE') return await orderApprove(msg);
  if (msg?.type==='ORDER_INSPECT_UI') return await orderInspectUi();
  if (msg?.type==='PRIVATE_CONFIG') return await configurePrivatePortfolio(msg);
  if (msg?.type==='PRIVATE_START') return await capturePrivatePortfolio();
  if (msg?.type==='PRIVATE_CAPTURE') return await acceptPrivateCapture(msg,sender);
  if (msg?.type==='START_SYNC') return await startSync();
  if (msg?.type==='DIAGNOSE') return {ok:true,...await getTabDiagnostics()};
  if (msg?.type==='TOGGLE_AUTO') {
    const {autoSync}=await chrome.storage.local.get('autoSync');
    const enabled=!autoSync;
    await chrome.storage.local.set({autoSync:enabled});
    if (enabled) await chrome.alarms.create('quote_sync',{periodInMinutes:30});
    else await chrome.alarms.clear('quote_sync');
    return {ok:true,enabled};
  }
  if (['PROGRESS','COLLECT_FAILED','COLLECT_DONE'].includes(msg?.type)) {
    const {syncTabId,syncRunning,syncRunId}=await chrome.storage.local.get(['syncTabId','syncRunning','syncRunId']);
    if (sender.tab?.id!==syncTabId || !syncRunning) return {ok:false,error:'Captura no reconocida'};
    if (msg.type==='PROGRESS') {
      const d=msg.detail||{};
      const phases=new Set(['START','CATEGORY','FIRST_PAGE','READ_PAGE','NEXT_PAGE','UPLOAD']);
      const categories=new Set(['ACCIONES','ETFs','FONDOS']);
      const value=Number.isInteger(d.captured)&&d.captured>=0&&d.captured<=226?
        d.captured:0;
      const progress={
        stage:phases.has(d.phase)?d.phase:'READ_PAGE',
        category:categories.has(d.category)?d.category:null,
        page:Number.isInteger(d.page)&&d.page>=1&&d.page<=30?d.page:null,
        captured:value,total:226,updatedAt:Date.now()
      };
      await chrome.storage.local.set({
        syncStatus:typeof msg.status==='string'?msg.status.slice(0,200):
          'Recopilando cotizaciones…',
        syncRunning:true,syncProgress:progress
      });
      return {ok:true};
    }
    if (msg.type==='COLLECT_FAILED') {
      await setStatus('Cotizaciones pendientes: '+(msg.reason||'lectura incompleta')+
        '. Guardando diagnóstico privado; la cartera se procesa por separado.',false);
      await chrome.storage.local.set({syncProgress:{
        stage:'Error de captura',captured:0,total:226,category:null,
        page:null,updatedAt:Date.now()}});
      let diagnosticStatus='unavailable';
      try {
        const saved=await uploadPrivateDiagnostic(msg.diagnostic);
        diagnosticStatus=saved.ok?'saved':saved.reason;
      }catch(error){
        diagnosticStatus='upload_failed';
      }
      await chrome.storage.local.set({lastDiagnosticStatus:diagnosticStatus});
      // Background injector closes its own tab after collector.js completes.
      return {ok:true};
    }
    try {
      await setStatus('226 cotizaciones capturadas. Validando en GitHub…',true);
      await upload(msg.payload);
      await chrome.storage.local.set({lastSync:Date.now(),orderReviewAttempts:0});
      // GitHub Actions validates the new snapshot asynchronously. Recheck the
      // confirmed public file shortly afterward, then stage local proposals.
      await chrome.alarms.create('order_review_refresh',{delayInMinutes:0.5});
      await setStatus('226 cotizaciones enviadas a GitHub · '+stamp()+
        '. Pendiente de validación por GitHub.',false);
      await chrome.storage.local.set({syncProgress:{
        stage:'Enviado a GitHub, validación pendiente',captured:226,total:226,
        category:'FONDOS',page:null,updatedAt:Date.now()
      }});
      // Background injector closes its own tab after collector.js completes.
      return {ok:true};
    }catch(err) {
      await setStatus('Error en envío público: '+err.message+
        '. La cartera privada no se interrumpe.',false);
      // Background injector closes its own tab after collector.js completes.
      return {ok:false,error:err.message};
    }
  }
  return {ok:false,error:'Comando no reconocido'};
}
chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
  route(msg,sender).then(result=>reply({...result,version:'2.8.2'})).catch(async err=>{
    await setStatus('Error: '+err.message,false);
    reply({ok:false,error:err.message});
  });
  return true;
});
chrome.alarms.onAlarm.addListener(async alarm=>{
  if(alarm.name!=='quote_sync') return;
  const s=await chrome.storage.local.get(['autoSync','lastSync']);
  if(!s.autoSync || Date.now()-(s.lastSync||0)<28*60000) return;
  const tabs=await getActinverTabs();
  const tab=tabs.matches.find(t=>t.active);
  if(tab) await startSync(tab.id);
});
async function maybeAutoStart(){
  const s=await chrome.storage.local.get(['autoSync','lastSync','syncRunning','lastAutoAttempt']);
  if(!s.autoSync || s.syncRunning || Date.now()-(s.lastSync||0)<28*60000 ||
     Date.now()-(s.lastAutoAttempt||0)<3*60000)return;
  const tabs=await getActinverTabs();
  if(!tabs.matches.length)return;
  await chrome.storage.local.set({lastAutoAttempt:Date.now()});
  const result=await startSync();
  if(!result.ok)await setStatus('Esperando a Actinver: '+result.error,false);
}
async function ensureAutoSync(){
  const {autoSync}=await chrome.storage.local.get('autoSync');
  if(autoSync===false){await chrome.alarms.clear('quote_sync');return;}
  if(autoSync!==true)await chrome.storage.local.set({autoSync:true});
  await chrome.alarms.create('quote_sync',{periodInMinutes:30});
  await maybeAutoStart();
}
chrome.runtime.onInstalled.addListener(()=>{void ensureAutoSync();});
chrome.runtime.onStartup.addListener(()=>{void ensureAutoSync();});
chrome.tabs.onUpdated.addListener((tabId,info,tab)=>{
  if(info.status==='complete' && ACTINVER.test(tab.url||''))void maybeAutoStart();
});

// Remote read-only quote capture requests initiated from ChatGPT via GitHub.
importScripts('remote.js');
importScripts('private-sync.js');
importScripts('order-preflight.js');
